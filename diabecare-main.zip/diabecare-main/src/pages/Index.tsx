import { Layout } from "@/components/Layout";
import { FeatureCard } from "@/components/FeatureCard";
import { Calculator, Stethoscope, Pill, Activity, Bell, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import WeeklyAnalysis from "@/components/WeeklyAnalysis";

const Index = () => {
  return (
    <Layout>
      {/* Header */}
      <header className="bg-gradient-to-r from-primary to-accent p-6 text-primary-foreground">
        <div className="max-w-screen-xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Activity className="h-7 w-7" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">DiabeCare</h1>
              <p className="text-sm text-primary-foreground/80">Your Health Companion</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button size="icon" variant="ghost" className="text-primary-foreground hover:bg-white/20">
              <Bell className="h-5 w-5" />
            </Button>
            <Button size="icon" variant="ghost" className="text-primary-foreground hover:bg-white/20">
              <Phone className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-screen-xl mx-auto px-4 py-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-2">Welcome Back!</h2>
          <p className="text-muted-foreground">Manage your diabetes with ease</p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FeatureCard
            icon={Calculator}
            title="Meal Dose Calculator"
            description="Calculate insulin dose for your meals"
            to="/meal-dose"
            gradient="primary"
          />
          
          <FeatureCard
            icon={Stethoscope}
            title="Doctor Contact List"
            description="Quick access to your healthcare providers"
            to="/doctors"
            gradient="secondary"
          />
          
          <FeatureCard
            icon={Pill}
            title="Medical Supplies"
            description="Order medicines and insulin supplies"
            to="/medical-stuff"
            gradient="secondary"
          />
          
          <FeatureCard
            icon={Activity}
            title="Blood Test & Reports"
            description="Upload and track your test results"
            to="/blood-test"
            gradient="primary"
          />
        </div>

        {/* Weekly Analysis */}
        <div className="mt-8">
          <WeeklyAnalysis />
        </div>

        {/* Health Tip Card */}
        <div className="mt-8 rounded-2xl bg-gradient-to-br from-secondary/10 to-success/10 border border-secondary/20 p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-secondary/20">
              <Activity className="h-6 w-6 text-secondary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">Daily Health Tip</h3>
              <p className="text-sm text-muted-foreground">
                Regular monitoring of blood glucose levels helps maintain better diabetes control. 
                Don't forget to log your readings!
              </p>
            </div>
          </div>
        </div>
      </main>
    </Layout>
  );
};

export default Index;
