import { useState } from "react";
import { Layout } from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, User, Save } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

const Profile = () => {
  const [formData, setFormData] = useState({
    name: "",
    contact: "",
    address: "",
    doctorContact: "",
    diagnosisAge: "",
    diabetesType: "",
    medicationType: "",
    insulinName: "",
    deliveryMethod: "",
    dosesPerDay: "",
    icr: "",
    correctionFactor: "",
    targetBG: "110",
    tdd: "",
  });

  const handleSave = () => {
    toast.success("Profile saved successfully!");
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <Layout>
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto flex items-center gap-3">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold text-foreground">Profile</h1>
            <p className="text-sm text-muted-foreground">Manage your health information</p>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-primary" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                placeholder="Enter your name"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact">Contact Number</Label>
              <Input
                id="contact"
                type="tel"
                placeholder="Enter phone number"
                value={formData.contact}
                onChange={(e) => handleInputChange("contact", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                placeholder="Enter your address"
                value={formData.address}
                onChange={(e) => handleInputChange("address", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="doctorContact">Doctor Contact Number</Label>
              <Input
                id="doctorContact"
                type="tel"
                placeholder="Enter doctor's phone number"
                value={formData.doctorContact}
                onChange={(e) => handleInputChange("doctorContact", e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Diabetes Information */}
        <Card>
          <CardHeader>
            <CardTitle>Diabetes Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="diagnosisAge">Age at Diagnosis</Label>
              <Input
                id="diagnosisAge"
                type="number"
                placeholder="Enter age"
                value={formData.diagnosisAge}
                onChange={(e) => handleInputChange("diagnosisAge", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="diabetesType">Diabetes Type</Label>
              <Select
                value={formData.diabetesType}
                onValueChange={(value) => handleInputChange("diabetesType", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="type1">Type 1</SelectItem>
                  <SelectItem value="type2">Type 2</SelectItem>
                  <SelectItem value="low">Low sugar only</SelectItem>
                  <SelectItem value="high">High sugar only</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="medicationType">Medication Type</Label>
              <Select
                value={formData.medicationType}
                onValueChange={(value) => handleInputChange("medicationType", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select medication" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="insulin">Insulin</SelectItem>
                  <SelectItem value="oral">Oral Medicine</SelectItem>
                  <SelectItem value="none">None</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Insulin Parameters */}
        <Card>
          <CardHeader>
            <CardTitle>Insulin Parameters</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="insulinName">Insulin Name</Label>
              <Input
                id="insulinName"
                placeholder="e.g., Humalog, NovoRapid"
                value={formData.insulinName}
                onChange={(e) => handleInputChange("insulinName", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="deliveryMethod">Delivery Method</Label>
              <Select
                value={formData.deliveryMethod}
                onValueChange={(value) => handleInputChange("deliveryMethod", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pump">Pump</SelectItem>
                  <SelectItem value="pen">Pen</SelectItem>
                  <SelectItem value="injection">Injection</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tdd">Total Daily Dose (TDD)</Label>
                <Input
                  id="tdd"
                  type="number"
                  placeholder="Units"
                  value={formData.tdd}
                  onChange={(e) => handleInputChange("tdd", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dosesPerDay">Doses Per Day</Label>
                <Input
                  id="dosesPerDay"
                  type="number"
                  placeholder="e.g., 3"
                  value={formData.dosesPerDay}
                  onChange={(e) => handleInputChange("dosesPerDay", e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="icr">ICR (Insulin-to-Carb Ratio)</Label>
                <Input
                  id="icr"
                  type="number"
                  placeholder="Optional"
                  value={formData.icr}
                  onChange={(e) => handleInputChange("icr", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="correctionFactor">Correction Factor</Label>
                <Input
                  id="correctionFactor"
                  type="number"
                  placeholder="Optional"
                  value={formData.correctionFactor}
                  onChange={(e) => handleInputChange("correctionFactor", e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetBG">Target Blood Glucose (mg/dL)</Label>
              <Input
                id="targetBG"
                type="number"
                placeholder="e.g., 110"
                value={formData.targetBG}
                onChange={(e) => handleInputChange("targetBG", e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        <Button onClick={handleSave} size="lg" className="w-full">
          <Save className="h-5 w-5 mr-2" />
          Save Profile
        </Button>
      </main>
    </Layout>
  );
};

export default Profile;
