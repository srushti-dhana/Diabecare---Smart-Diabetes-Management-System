import { Layout } from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Upload, Phone, FileText } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";

const BloodTest = () => {
  const handleUpload = () => {
    toast.info("Upload functionality will be available after backend setup");
  };

  const handleCallLab = () => {
    toast.info("Calling lab service...");
  };

  return (
    <Layout>
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto flex items-center gap-3">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-foreground">Blood Test & Reports</h1>
            <p className="text-sm text-muted-foreground">Manage your test results</p>
          </div>
          <Button variant="outline" size="icon" onClick={handleCallLab}>
            <Phone className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        {/* Lab Service Card */}
        <Card className="bg-gradient-to-br from-secondary/10 to-success/10 border-secondary/30">
          <CardHeader>
            <CardTitle className="text-secondary">Book Lab Service</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Schedule blood tests from the comfort of your home
            </p>
            <div className="flex flex-wrap gap-2">
              {["HbA1C", "Fasting Glucose", "Hemoglobin", "Lipid Profile", "Kidney Function"].map((test) => (
                <span
                  key={test}
                  className="px-3 py-1 bg-secondary/20 text-secondary text-xs font-medium rounded-full"
                >
                  {test}
                </span>
              ))}
            </div>
            <Button className="w-full" variant="default" onClick={handleCallLab}>
              <Phone className="h-4 w-4 mr-2" />
              Call Lab Service
            </Button>
          </CardContent>
        </Card>

        {/* Upload Section */}
        <Card className="border-dashed border-2">
          <CardContent className="p-8 text-center">
            <div className="max-w-sm mx-auto space-y-4">
              <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto">
                <Upload className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">
                  Upload Test Reports
                </h3>
                <p className="text-sm text-muted-foreground">
                  Upload your monthly or 6-month blood test reports for tracking
                </p>
              </div>
              <Button onClick={handleUpload} size="lg" className="w-full">
                <Upload className="h-5 w-5 mr-2" />
                Upload Report (Image/PDF)
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Reports */}
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">Recent Reports</h2>
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No reports uploaded yet</p>
              <p className="text-sm mt-1">Your test reports will appear here</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </Layout>
  );
};

export default BloodTest;
