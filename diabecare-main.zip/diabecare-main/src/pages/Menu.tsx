import { Layout } from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Settings, HelpCircle, FileText, LogOut, Shield } from "lucide-react";
import { toast } from "sonner";

const Menu = () => {
  const menuItems = [
    { icon: Settings, label: "Settings", action: () => toast.info("Settings coming soon") },
    { icon: HelpCircle, label: "Help & Support", action: () => toast.info("Help section coming soon") },
    { icon: FileText, label: "Terms & Conditions", action: () => toast.info("Terms coming soon") },
    { icon: Shield, label: "Privacy Policy", action: () => toast.info("Privacy policy coming soon") },
    { icon: LogOut, label: "Logout", action: () => toast.info("Logout functionality coming soon") },
  ];

  return (
    <Layout>
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto">
          <h1 className="text-xl font-bold text-foreground">Menu</h1>
          <p className="text-sm text-muted-foreground">Settings and more</p>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6">
        <Card>
          <CardContent className="p-2">
            {menuItems.map((item, idx) => {
              const Icon = item.icon;
              return (
                <Button
                  key={idx}
                  variant="ghost"
                  className="w-full justify-start gap-3 h-14"
                  onClick={item.action}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Button>
              );
            })}
          </CardContent>
        </Card>

        <div className="mt-6 text-center text-sm text-muted-foreground">
          <p>DiabeCare v1.0.0</p>
          <p className="mt-1">Made with ❤️ for diabetes management</p>
        </div>
      </main>
    </Layout>
  );
};

export default Menu;
