import { useState } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Calculator, AlertTriangle, Info, Plus, Check, Camera, X } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";

interface FoodItem {
  id: string;
  name: string;
  quantity: string;
  selected: boolean;
  image?: string;
}

interface CalculationResult {
  ICR: number;
  CorrectionFactor: number;
  BolusForCarbs: number;
  CorrectionDose: number;
  ActiveInsulin: number;
  TotalDose: number;
  RoundedDose: number;
  Warnings: string[];
  Disclaimer: string;
}

const MealDose = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [foodItems, setFoodItems] = useState<FoodItem[]>([
    { id: "1", name: "", quantity: "", selected: false },
  ]);

  const [nutritionData, setNutritionData] = useState({
    totalCarbs: "",
    totalFat: "",
    sugar: "",
    protein: "",
    currentBG: "",
    targetBG: "110",
    tdd: "",
    activeInsulin: "0",
  });

  const [result, setResult] = useState<CalculationResult | null>(null);

  // Food Selection Screen Functions
  const addFoodItem = () => {
    setFoodItems([...foodItems, { id: Date.now().toString(), name: "", quantity: "", selected: false }]);
  };

  const updateFoodItem = (id: string, field: "name" | "quantity" | "selected" | "image", value: string | boolean) => {
    setFoodItems(foodItems.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ));
  };

  const removeFoodItem = (id: string) => {
    if (foodItems.length > 1) {
      setFoodItems(foodItems.filter(item => item.id !== id));
    }
  };

  const handleImageUpload = (id: string, file: File) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateFoodItem(id, "image", reader.result as string);
        toast.success("Image uploaded successfully");
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = (id: string) => {
    updateFoodItem(id, "image", "");
  };

  // Navigation Functions
  const goToConfirmation = () => {
    const hasItems = foodItems.some(item => item.name.trim() !== "");
    if (!hasItems) {
      toast.error("Please add at least one food item");
      return;
    }
    setCurrentStep(2);
  };

  const goToCalculation = (confirm: boolean) => {
    if (confirm) {
      setCurrentStep(3);
    } else {
      setCurrentStep(1);
    }
  };

  // Calculation Function
  const calculateDose = () => {
    const currentBG = parseFloat(nutritionData.currentBG);
    const targetBG = parseFloat(nutritionData.targetBG);
    const carbs = parseFloat(nutritionData.totalCarbs);
    const tdd = parseFloat(nutritionData.tdd);
    const activeInsulin = parseFloat(nutritionData.activeInsulin);

    if (!currentBG || !targetBG || !carbs || !tdd) {
      toast.error("Please fill in all required fields");
      return;
    }

    const ICR = 500 / tdd;
    const CF = 1800 / tdd;

    const warnings: string[] = [];
    let insulinDose = 0;

    if (currentBG < 70) {
      warnings.push("⚠️ Low blood sugar (<70 mg/dL) — do NOT inject insulin. Eat 15–20g carbs immediately.");
    } else if (currentBG > 300) {
      warnings.push("⚠️ Very high blood sugar (>300 mg/dL) — consult your healthcare provider immediately.");
    }

    const bolusForCarbs = carbs / ICR;
    const correctionDose = Math.max((currentBG - targetBG) / CF, 0);
    
    if (currentBG >= 70) {
      insulinDose = bolusForCarbs + correctionDose - activeInsulin;
      insulinDose = Math.max(insulinDose, 0);
    }

    const roundedDose = Math.round(insulinDose * 2) / 2;

    const calculationResult: CalculationResult = {
      ICR: Math.round(ICR * 10) / 10,
      CorrectionFactor: Math.round(CF * 10) / 10,
      BolusForCarbs: Math.round(bolusForCarbs * 10) / 10,
      CorrectionDose: Math.round(correctionDose * 10) / 10,
      ActiveInsulin: activeInsulin,
      TotalDose: Math.round(insulinDose * 10) / 10,
      RoundedDose: roundedDose,
      Warnings: warnings,
      Disclaimer: "⚕️ This app is made for educational purposes and the developers are not responsible for any misuse or mistook of amount of insulin.",
    };

    setResult(calculationResult);

    // Save to history
    const historyEntry = {
      id: Date.now(),
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      currentBG,
      targetBG,
      carbs,
      tdd,
      dose: roundedDose,
      foodItems: foodItems
        .filter(item => item.name.trim() !== "")
        .map(item => ({
          name: item.name,
          quantity: item.quantity,
          image: item.image
        })),
      nutritionData: {
        totalFat: nutritionData.totalFat,
        sugar: nutritionData.sugar,
        protein: nutritionData.protein
      }
    };

    // Get existing history from localStorage
    const existingHistory = JSON.parse(localStorage.getItem('mealDoseHistory') || '[]');
    
    // Add new entry at the beginning
    existingHistory.unshift(historyEntry);
    
    // Save back to localStorage
    localStorage.setItem('mealDoseHistory', JSON.stringify(existingHistory));

    toast.success("Calculation complete and saved to history!");
  };

  return (
    <Layout>
      {/* Header */}
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto flex items-center gap-3">
          {currentStep > 1 ? (
            <Button variant="ghost" size="icon" onClick={() => setCurrentStep(currentStep - 1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
          ) : (
            <Link to="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
          )}
          <div>
            <h1 className="text-xl font-bold text-foreground">Meal Dose Calculator</h1>
            <p className="text-sm text-muted-foreground">Step {currentStep} of 3</p>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        {/* Step 1: Food Selection */}
        {currentStep === 1 && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Add Food Items</CardTitle>
                <CardDescription>List all food items from your previous screen</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {foodItems.map((item, index) => (
                  <div key={item.id} className="flex items-start gap-3 p-4 border border-border rounded-lg">
                    <div className="pt-2">
                      <Checkbox
                        checked={item.selected}
                        onCheckedChange={(checked) => updateFoodItem(item.id, "selected", checked as boolean)}
                      />
                    </div>
                    <div className="flex-1 space-y-3">
                      <div className="space-y-2">
                        <Label>Name of Food Item</Label>
                        <Input
                          placeholder="e.g., Rice, Chicken, Apple"
                          value={item.name}
                          onChange={(e) => updateFoodItem(item.id, "name", e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Quantity</Label>
                        <Input
                          placeholder="e.g., 1 cup, 100g"
                          value={item.quantity}
                          onChange={(e) => updateFoodItem(item.id, "quantity", e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Food Image (Optional)</Label>
                        {item.image ? (
                          <div className="relative">
                            <img 
                              src={item.image} 
                              alt={item.name} 
                              className="w-full h-32 object-cover rounded-lg"
                            />
                            <Button
                              variant="destructive"
                              size="icon"
                              className="absolute top-2 right-2 h-8 w-8"
                              onClick={() => removeImage(item.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <div className="relative">
                            <Input
                              id={`image-${item.id}`}
                              type="file"
                              accept="image/*"
                              capture="environment"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleImageUpload(item.id, file);
                              }}
                            />
                            <Button
                              type="button"
                              variant="outline"
                              className="w-full"
                              onClick={() => document.getElementById(`image-${item.id}`)?.click()}
                            >
                              <Camera className="h-4 w-4 mr-2" />
                              Add Food Image
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                <Button variant="outline" onClick={addFoodItem} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Another Food Item
                </Button>
              </CardContent>
            </Card>

            {/* Health Tips Section */}
            <Card className="bg-gradient-to-br from-secondary/10 to-success/10 border-secondary/20">
              <CardContent className="p-6">
                <h3 className="font-semibold text-foreground mb-3">💡 Healthy Eating Tips</h3>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>• Balance your meals with proteins, carbs, and healthy fats</p>
                  <p>• Monitor portion sizes to maintain stable blood sugar</p>
                  <p>• Choose whole grains over refined carbohydrates</p>
                  <p>• Stay hydrated throughout the day</p>
                  <p className="italic mt-4">"Good nutrition is a responsibility, not a restriction."</p>
                </div>
              </CardContent>
            </Card>

            <Button onClick={goToConfirmation} size="lg" className="w-full">
              Continue to Review
            </Button>
          </>
        )}

        {/* Step 2: Confirmation */}
        {currentStep === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Review Your Food Items</CardTitle>
              <CardDescription>Confirm the items added to your meal</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                {foodItems.filter(item => item.name.trim() !== "").map((item) => (
                  <div key={item.id} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <Check className="h-5 w-5 text-success" />
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{item.name}</p>
                      <p className="text-sm text-muted-foreground">{item.quantity}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-border pt-6">
                <p className="text-center font-medium text-foreground mb-4">
                  Are you sure about the items added in the cart?<br />
                  Or you want to add more?
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => goToCalculation(false)}
                  >
                    NO - Add More
                  </Button>
                  <Button
                    size="lg"
                    onClick={() => goToCalculation(true)}
                  >
                    YES - Continue
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Calculation */}
        {currentStep === 3 && (
          <>
            {/* Warning Banner */}
            <Alert className="bg-warning/10 border-warning/30">
              <AlertTriangle className="h-4 w-4 text-warning" />
              <AlertDescription className="text-sm">
                Make it like a warning & a safe side for us, since any one can sue us for wrong calculations.
              </AlertDescription>
            </Alert>

            {/* Nutrition Input */}
            <Card>
              <CardHeader>
                <CardTitle>Nutritional Information</CardTitle>
                <CardDescription>Enter total nutritional values for all food items</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="totalCarbs">① Total Carbs in all food items (grams) *</Label>
                  <Input
                    id="totalCarbs"
                    type="number"
                    placeholder="e.g., 60"
                    value={nutritionData.totalCarbs}
                    onChange={(e) => setNutritionData({...nutritionData, totalCarbs: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="totalFat">② Total Fat in all food items (grams)</Label>
                  <Input
                    id="totalFat"
                    type="number"
                    placeholder="e.g., 20"
                    value={nutritionData.totalFat}
                    onChange={(e) => setNutritionData({...nutritionData, totalFat: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sugar">③ Sugar (grams)</Label>
                  <Input
                    id="sugar"
                    type="number"
                    placeholder="e.g., 15"
                    value={nutritionData.sugar}
                    onChange={(e) => setNutritionData({...nutritionData, sugar: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="protein">④ Protein (grams)</Label>
                  <Input
                    id="protein"
                    type="number"
                    placeholder="e.g., 30"
                    value={nutritionData.protein}
                    onChange={(e) => setNutritionData({...nutritionData, protein: e.target.value})}
                  />
                </div>

                <div className="border-t border-border my-4"></div>

                <div className="space-y-2">
                  <Label htmlFor="currentBG">Current Blood Glucose (mg/dL) *</Label>
                  <Input
                    id="currentBG"
                    type="number"
                    placeholder="e.g., 190"
                    value={nutritionData.currentBG}
                    onChange={(e) => setNutritionData({...nutritionData, currentBG: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="targetBG">Target Blood Glucose (mg/dL) *</Label>
                  <Input
                    id="targetBG"
                    type="number"
                    placeholder="e.g., 110"
                    value={nutritionData.targetBG}
                    onChange={(e) => setNutritionData({...nutritionData, targetBG: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tdd">Total Daily Dose (TDD) *</Label>
                  <Input
                    id="tdd"
                    type="number"
                    placeholder="e.g., 40"
                    value={nutritionData.tdd}
                    onChange={(e) => setNutritionData({...nutritionData, tdd: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="activeInsulin">Active Insulin (units)</Label>
                  <Input
                    id="activeInsulin"
                    type="number"
                    placeholder="e.g., 0"
                    value={nutritionData.activeInsulin}
                    onChange={(e) => setNutritionData({...nutritionData, activeInsulin: e.target.value})}
                  />
                </div>

                <Button onClick={calculateDose} className="w-full" size="lg">
                  <Calculator className="h-5 w-5 mr-2" />
                  Calculate Insulin Dose
                </Button>
              </CardContent>
            </Card>

            {/* Results */}
            {result && (
              <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-accent/5">
                <CardHeader>
                  <CardTitle className="text-primary">Total Amount of Insulin to be Taken</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {result.Warnings.length > 0 && (
                    <div className="space-y-2">
                      {result.Warnings.map((warning, idx) => (
                        <Alert key={idx} className="bg-destructive/10 border-destructive/30">
                          <AlertTriangle className="h-4 w-4 text-destructive" />
                          <AlertDescription className="text-sm font-medium">{warning}</AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  )}

                  <div className="pt-4 border-t border-border">
                    <div className="bg-primary/10 rounded-xl p-6 text-center">
                      <p className="text-sm text-muted-foreground mb-2">Recommended Insulin Dose with this meal</p>
                      <p className="text-5xl font-bold text-primary mb-2">{result.RoundedDose}</p>
                      <p className="text-lg text-muted-foreground">units</p>
                    </div>
                  </div>

                  <Alert className="bg-warning/10 border-warning/30">
                    <Info className="h-4 w-4 text-warning" />
                    <AlertDescription className="text-xs font-medium">
                      {result.Disclaimer}
                      <br /><br />
                      Also write: we can have given the amount of an insulin to be taken according to the meal provided, we are not responsible for any miscalculations in the meals provided by user.
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </main>
    </Layout>
  );
};

export default MealDose;
