import { Layout } from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Upload, Image as ImageIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { useState } from "react";

const SugarCheck = () => {
  const [uploadedImages, setUploadedImages] = useState<Array<{ id: string; url: string; date: string }>>([]);

  const handleImageUpload = (file: File) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newImage = {
          id: Date.now().toString(),
          url: reader.result as string,
          date: new Date().toLocaleString(),
        };
        setUploadedImages([newImage, ...uploadedImages]);
        toast.success("Sugar check image uploaded successfully");
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Layout>
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto flex items-center gap-3">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold text-foreground">Sugar Check</h1>
            <p className="text-sm text-muted-foreground">Upload your glucose readings</p>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        <Card className="border-dashed border-2">
          <CardContent className="p-8 text-center">
            <div className="max-w-sm mx-auto space-y-4">
              <div className="p-4 rounded-full bg-primary/10 w-fit mx-auto">
                <Upload className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Upload Sugar Check Image</h3>
                <p className="text-sm text-muted-foreground">
                  Take a photo of your glucose meter or upload an existing image
                </p>
              </div>
              <input
                id="sugar-check-upload"
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleImageUpload(file);
                }}
              />
              <Button 
                onClick={() => document.getElementById('sugar-check-upload')?.click()} 
                size="lg" 
                className="w-full"
              >
                <Upload className="h-5 w-5 mr-2" />
                Upload Image
              </Button>
            </div>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">Recent Uploads</h2>
          {uploadedImages.length > 0 ? (
            <div className="space-y-3">
              {uploadedImages.map((image) => (
                <Card key={image.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <img 
                        src={image.url} 
                        alt="Sugar check" 
                        className="w-24 h-24 object-cover rounded-lg border border-border"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">Sugar Check Reading</p>
                        <p className="text-xs text-muted-foreground mt-1">{image.date}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-6 text-center text-muted-foreground">
                <ImageIcon className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No images uploaded yet</p>
                <p className="text-sm mt-1">Your uploaded sugar check images will appear here</p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </Layout>
  );
};

export default SugarCheck;
