import { Layout } from "@/components/Layout";
import { FeatureCard } from "@/components/FeatureCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Pill, MapPin, Syringe, MessageCircle, Truck, Search } from "lucide-react";
import { Link } from "react-router-dom";

const MedicalStuff = () => {
  return (
    <Layout>
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto flex items-center gap-3">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-foreground">Medical Supplies</h1>
            <p className="text-sm text-muted-foreground">Order medicines and supplies</p>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search for medicines, supplies..."
            className="pl-10 h-12"
          />
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FeatureCard
            icon={Pill}
            title="All Medicines"
            description="Browse complete medicine catalog"
            to="/medicines"
            gradient="primary"
          />
          
          <FeatureCard
            icon={MapPin}
            title="Medical Store Near You"
            description="Find nearby pharmacies"
            to="/stores"
            gradient="secondary"
          />
          
          <FeatureCard
            icon={Syringe}
            title="Insulin Supplies"
            description="Pens, cartridges, and needles"
            to="/insulin-supplies"
            gradient="primary"
          />
          
          <FeatureCard
            icon={MessageCircle}
            title="WhatsApp Connect"
            description="Chat with pharmacist"
            to="/whatsapp"
            gradient="secondary"
          />
          
          <FeatureCard
            icon={Truck}
            title="Fast Delivery"
            description="Express medicine delivery"
            to="/delivery"
            gradient="primary"
          />
        </div>
      </main>
    </Layout>
  );
};

export default MedicalStuff;
