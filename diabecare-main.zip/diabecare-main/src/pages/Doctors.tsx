import { Layout } from "@/components/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Phone, Mail, MapPin, Stethoscope } from "lucide-react";
import { Link } from "react-router-dom";

const Doctors = () => {
  // Mock data - will be replaced with real data
  const doctors = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      specialty: "Endocrinologist",
      phone: "+1 (555) 123-4567",
      email: "sarah.johnson@hospital.com",
      location: "City General Hospital",
    },
    {
      id: 2,
      name: "Dr. Michael Chen",
      specialty: "Diabetologist",
      phone: "+1 (555) 987-6543",
      email: "michael.chen@clinic.com",
      location: "Diabetes Care Clinic",
    },
  ];

  return (
    <Layout>
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto flex items-center gap-3">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold text-foreground">Doctor Contacts</h1>
            <p className="text-sm text-muted-foreground">Your healthcare providers</p>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6 space-y-4">
        {doctors.map((doctor) => (
          <Card key={doctor.id}>
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl bg-primary/10">
                  <Stethoscope className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1 space-y-3">
                  <div>
                    <h3 className="font-semibold text-foreground text-lg">{doctor.name}</h3>
                    <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <a href={`tel:${doctor.phone}`} className="text-primary hover:underline">
                        {doctor.phone}
                      </a>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <a href={`mailto:${doctor.email}`} className="text-primary hover:underline">
                        {doctor.email}
                      </a>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="text-foreground">{doctor.location}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button size="sm" className="flex-1">
                      <Phone className="h-4 w-4 mr-2" />
                      Call
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <Mail className="h-4 w-4 mr-2" />
                      Email
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </main>
    </Layout>
  );
};

export default Doctors;
