import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Phone, Clock, MapPin, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { GoogleMap, LoadScript, Marker, InfoWindow } from "@react-google-maps/api";

const mapContainerStyle = {
  width: "100%",
  height: "500px",
};

const center = {
  lat: 28.6139,
  lng: 77.209,
};

// Mock data for medical stores
const medicalStores = [
  {
    id: 1,
    name: "Apollo Pharmacy",
    position: { lat: 28.6139, lng: 77.209 },
    phone: "+91 9876543210",
    isOpen: true,
    openTime: "24/7",
    hasMedicine: true,
    address: "123 Main Street, Delhi",
  },
  {
    id: 2,
    name: "MedPlus",
    position: { lat: 28.6189, lng: 77.2145 },
    phone: "+91 9876543211",
    isOpen: true,
    openTime: "8 AM - 10 PM",
    hasMedicine: false,
    address: "456 Park Road, Delhi",
  },
  {
    id: 3,
    name: "Wellness Pharmacy",
    position: { lat: 28.6089, lng: 77.2035 },
    phone: "+91 9876543212",
    isOpen: false,
    openTime: "9 AM - 9 PM",
    hasMedicine: true,
    address: "789 Health Center, Delhi",
  },
];

const MedicalStores = () => {
  const [selectedStore, setSelectedStore] = useState<typeof medicalStores[0] | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [apiKey, setApiKey] = useState("");

  return (
    <Layout>
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto flex items-center gap-3">
          <Link to="/medical-stuff">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-foreground">Medical Stores Near You</h1>
            <p className="text-sm text-muted-foreground">Find pharmacies and check availability</p>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        {/* API Key Input */}
        {!apiKey && (
          <Card className="border-primary/20 bg-primary/5">
            <CardHeader>
              <CardTitle className="text-lg">Enter Google Maps API Key</CardTitle>
              <CardDescription>
                Get your API key from{" "}
                <a
                  href="https://console.cloud.google.com/google/maps-apis"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  Google Cloud Console
                </a>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input
                placeholder="Enter your Google Maps API key"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
              />
            </CardContent>
          </Card>
        )}

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search for medicine..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12"
          />
        </div>

        {/* Map */}
        {apiKey ? (
          <Card>
            <CardContent className="p-0">
              <LoadScript googleMapsApiKey={apiKey}>
                <GoogleMap
                  mapContainerStyle={mapContainerStyle}
                  center={center}
                  zoom={13}
                >
                  {medicalStores.map((store) => (
                    <Marker
                      key={store.id}
                      position={store.position}
                      onClick={() => setSelectedStore(store)}
                    />
                  ))}

                  {selectedStore && (
                    <InfoWindow
                      position={selectedStore.position}
                      onCloseClick={() => setSelectedStore(null)}
                    >
                      <div className="p-2">
                        <h3 className="font-semibold text-foreground">{selectedStore.name}</h3>
                        <p className="text-sm text-muted-foreground">{selectedStore.address}</p>
                      </div>
                    </InfoWindow>
                  )}
                </GoogleMap>
              </LoadScript>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="flex items-center justify-center h-[500px]">
              <p className="text-muted-foreground">Please enter your Google Maps API key to view the map</p>
            </CardContent>
          </Card>
        )}

        {/* Store List */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-foreground">Nearby Pharmacies</h2>
          <div className="grid gap-4">
            {medicalStores.map((store) => (
              <Card key={store.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{store.name}</CardTitle>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        <span>{store.address}</span>
                      </div>
                    </div>
                    <Badge variant={store.isOpen ? "default" : "secondary"}>
                      {store.isOpen ? "Open" : "Closed"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{store.openTime}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <a href={`tel:${store.phone}`} className="text-primary hover:underline">
                      {store.phone}
                    </a>
                  </div>
                  {searchQuery && (
                    <div className="pt-2 border-t">
                      <Badge variant={store.hasMedicine ? "default" : "secondary"}>
                        {store.hasMedicine ? "Medicine Available" : "Not Available"}
                      </Badge>
                    </div>
                  )}
                  <Button className="w-full mt-2" onClick={() => setSelectedStore(store)}>
                    View on Map
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </Layout>
  );
};

export default MedicalStores;
