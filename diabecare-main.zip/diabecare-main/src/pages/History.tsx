import { useState, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calculator, FileText, Calendar } from "lucide-react";
import { Link } from "react-router-dom";

interface FoodItem {
  name: string;
  quantity: string;
  image?: string;
}

interface HistoryEntry {
  id: number;
  date: string;
  time: string;
  currentBG: number;
  targetBG: number;
  carbs: number;
  tdd: number;
  dose: number;
  foodItems: FoodItem[];
  nutritionData?: {
    totalFat?: string;
    sugar?: string;
    protein?: string;
  };
}

const History = () => {
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  useEffect(() => {
    // Load history from localStorage
    const loadHistory = () => {
      const savedHistory = localStorage.getItem('mealDoseHistory');
      if (savedHistory) {
        setHistory(JSON.parse(savedHistory));
      }
    };

    loadHistory();

    // Listen for storage changes (when new calculations are added)
    const handleStorageChange = () => {
      loadHistory();
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Also check for changes when window regains focus
    window.addEventListener('focus', loadHistory);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('focus', loadHistory);
    };
  }, []);

  return (
    <Layout>
      <header className="bg-card border-b border-border p-4">
        <div className="max-w-screen-xl mx-auto flex items-center gap-3">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-xl font-bold text-foreground">History</h1>
            <p className="text-sm text-muted-foreground">Your calculation and report history</p>
          </div>
        </div>
      </header>

      <main className="max-w-screen-xl mx-auto px-4 py-6 space-y-6">
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">Meal Dose Calculations</h2>
          {history.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center text-muted-foreground">
                <Calculator className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No calculations yet</p>
                <p className="text-sm mt-1">Your meal dose calculations will appear here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {history.map((item) => (
                <Card key={item.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <Calculator className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <p className="text-sm text-muted-foreground">
                              {item.date} at {item.time}
                            </p>
                          </div>
                          <div className="space-y-2">
                            <div>
                              <p className="text-xs text-muted-foreground font-medium mb-1">Food Items:</p>
                              <div className="space-y-2">
                                {item.foodItems.map((food, idx) => (
                                  <div key={idx} className="pl-2 border-l-2 border-primary/30">
                                    {food.image && (
                                      <img 
                                        src={food.image} 
                                        alt={food.name}
                                        className="w-20 h-20 object-cover rounded mb-1"
                                      />
                                    )}
                                    <p className="text-sm">
                                      <span className="font-medium">{food.name}</span>
                                      <span className="text-muted-foreground"> - {food.quantity}</span>
                                    </p>
                                  </div>
                                ))}
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-4 text-sm">
                              <p>
                                <span className="text-muted-foreground">BG:</span>{" "}
                                <span className="font-medium">{item.currentBG} mg/dL</span>
                              </p>
                              <p>
                                <span className="text-muted-foreground">Carbs:</span>{" "}
                                <span className="font-medium">{item.carbs}g</span>
                              </p>
                              {item.nutritionData?.totalFat && (
                                <p>
                                  <span className="text-muted-foreground">Fat:</span>{" "}
                                  <span className="font-medium">{item.nutritionData.totalFat}g</span>
                                </p>
                              )}
                              {item.nutritionData?.protein && (
                                <p>
                                  <span className="text-muted-foreground">Protein:</span>{" "}
                                  <span className="font-medium">{item.nutritionData.protein}g</span>
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-right ml-3">
                        <p className="text-xs text-muted-foreground mb-1">Dose</p>
                        <p className="text-lg font-bold text-primary">{item.dose}u</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">Uploaded Documents</h2>
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No documents uploaded yet</p>
              <p className="text-sm mt-1">Upload blood test reports to see them here</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </Layout>
  );
};

export default History;
