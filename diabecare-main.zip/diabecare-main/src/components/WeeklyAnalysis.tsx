import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { useEffect, useState } from "react";

interface DoseHistory {
  timestamp: string;
  roundedDose: number;
  currentBG: number;
  targetBG: number;
  totalCarbs: number;
}

const WeeklyAnalysis = () => {
  const [weeklyData, setWeeklyData] = useState<any[]>([]);

  useEffect(() => {
    // Get history from localStorage
    const history = JSON.parse(localStorage.getItem("mealDoseHistory") || "[]") as DoseHistory[];
    
    // Get last 7 days
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    // Filter and group by day
    const dailyData: { [key: string]: { doses: number[], bgLevels: number[], count: number } } = {};
    
    history.forEach((entry) => {
      const date = new Date(entry.timestamp);
      if (date >= sevenDaysAgo) {
        const dayKey = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        
        if (!dailyData[dayKey]) {
          dailyData[dayKey] = { doses: [], bgLevels: [], count: 0 };
        }
        
        dailyData[dayKey].doses.push(entry.roundedDose);
        dailyData[dayKey].bgLevels.push(entry.currentBG);
        dailyData[dayKey].count++;
      }
    });
    
    // Calculate averages for chart
    const chartData = Object.entries(dailyData).map(([day, data]) => ({
      day,
      avgDose: (data.doses.reduce((a, b) => a + b, 0) / data.count).toFixed(1),
      avgBG: (data.bgLevels.reduce((a, b) => a + b, 0) / data.count).toFixed(0),
      targetBG: 100, // Target line
    }));
    
    setWeeklyData(chartData);
  }, []);

  if (weeklyData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Weekly Analysis</CardTitle>
          <CardDescription>Sugar levels and correctional doses</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64 text-muted-foreground">
            No data available. Start tracking your meal doses to see weekly analysis.
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Weekly Analysis</CardTitle>
        <CardDescription>Sugar levels and correctional doses over the last 7 days</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Blood Glucose Chart */}
          <div>
            <h3 className="text-sm font-medium mb-3">Average Blood Glucose (mg/dL)</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="day" 
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px',
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="avgBG" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  name="Avg Blood Glucose"
                  dot={{ fill: 'hsl(var(--primary))' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="targetBG" 
                  stroke="hsl(var(--muted-foreground))" 
                  strokeDasharray="5 5"
                  name="Target"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Insulin Dose Chart */}
          <div>
            <h3 className="text-sm font-medium mb-3">Average Correctional Dose (Units)</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="day" 
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px',
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="avgDose" 
                  stroke="hsl(var(--chart-2))" 
                  strokeWidth={2}
                  name="Avg Insulin Dose"
                  dot={{ fill: 'hsl(var(--chart-2))' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WeeklyAnalysis;
