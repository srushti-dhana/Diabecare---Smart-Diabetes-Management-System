import { LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  to: string;
  gradient?: "primary" | "secondary";
}

export const FeatureCard = ({
  icon: Icon,
  title,
  description,
  to,
  gradient = "primary",
}: FeatureCardProps) => {
  return (
    <Link
      to={to}
      className={cn(
        "group relative overflow-hidden rounded-2xl p-6 transition-all hover:scale-[1.02] hover:shadow-lg",
        "bg-card border border-border",
        "active:scale-[0.98]"
      )}
    >
      <div
        className={cn(
          "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity",
          gradient === "primary" && "bg-gradient-to-br from-primary/10 to-accent/10",
          gradient === "secondary" && "bg-gradient-to-br from-secondary/10 to-success/10"
        )}
      />
      
      <div className="relative flex flex-col items-start gap-3">
        <div
          className={cn(
            "p-3 rounded-xl",
            gradient === "primary" && "bg-primary/10 text-primary",
            gradient === "secondary" && "bg-secondary/10 text-secondary"
          )}
        >
          <Icon className="h-6 w-6" />
        </div>
        
        <div className="space-y-1">
          <h3 className="font-semibold text-foreground">{title}</h3>
          {description && (
            <p className="text-sm text-muted-foreground">{description}</p>
          )}
        </div>
      </div>
    </Link>
  );
};
